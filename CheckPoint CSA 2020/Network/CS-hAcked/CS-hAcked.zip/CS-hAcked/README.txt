                 uuuuuuu
             uu$$$$$$$$$$$uu
          uu$$$$$$$$$$$$$$$$$uu
         u$$$$$$$$$$$$$$$$$$$$$u
        u$$$$$$$$$$$$$$$$$$$$$$$u
       u$$$$$$$$$$$$$$$$$$$$$$$$$u
       u$$$$$$$$$$$$$$$$$$$$$$$$$u
       u$$$$$$"   "$$$"   "$$$$$$u
       "$$$$"      u$u       $$$$"
        $$$u       u$u       u$$$
        $$$u      u$$$u      u$$$
         "$$$$uu$$$   $$$uu$$$$"
          "$$$$$$$"   "$$$$$$$"
            u$$$$$$$u$$$$$$$u
             u$"$"$"$"$"$"$u
  uuu        $$u$ $ $ $ $u$$       uuu
 u$$$$        $$$$$u$u$u$$$       u$$$$
  $$$$$uu      "$$$$$$$$$"     uu$$$$$$
u$$$$$$$$$$$uu    """""    uuuu$$$$$$$$$$
$$$$"""$$$$$$$$$$uuu   uu$$$$$$$$$"""$$$"
 """      ""$$$$$$$$$$$uu ""$"""
           uuuu ""$$$$$$$$$$uuu
  u$$$uuu$$$$$$$$$uu ""$$$$$$$$$$$uuu$$$
  $$$$$$$$$$""""           ""$$$$$$$$$$$"
   "$$$$$"                      ""$$$$""
     $$$"                         $$$$"
                CS-hAcked

 
 Dear fellow, we've heard you've got some hacking skills - this is the time to use them ;)
 For some time now we've been investing great efforts to get a hold of an extremely dangerous hacking team network that goes by the name "CS-hAcked". 
 According to our intelligence, we believe that on this network they transfer their secret combination  - being used as a trigger to 
 every major attack they commit.
 Recently we've come to a major breakthrough, completing successfully an operation to achieve remote control on one of the computers in the network.
 That's where you get into the picture.
 Your mission, should you choose to accept it, is to infiltrate their network using our implanted backdoor,
 and reveal once and for all the secret combination to finally get the secret flag.
 
 Thanks to our dedicated intelligence researchers we gathered the following information for you that might assist you:
 1. We know the dictionary of words they've used over time. It's highly probable they'll use it for their current combination.
 2. Our backdoor PC credentials - IP: 3.126.154.76 , port:2222, username:csa, pass:123123
 3. The flag server IP: 3.126.154.76  port: 80
 
 And perhaps the following could help you as well:
 https://en.wikipedia.org/wiki/Man-in-the-middle_attack
 https://www.techrepublic.com/article/how-to-scan-for-ip-addresses-on-your-network-with-linux/
 https://en.wikipedia.org/wiki/ARP_spoofing
 
 As always, should you or any of your members be caught or hacked, the secretary will disavow any knowledge of your actions. 
 This page will self-destruct in few weeks.
 Good Luck! 