﻿Welcome to the land of CSA!

In this challenge you'll help our CSA hero KEEN to find the lost FLAG :)
The flag is hidden somewhere in the game code.
To complete the mission you'll have to use the attached game code.

IMPORTANT: submit the flag in the following format: CSA{...}.

GOOD LUCK!
	    ________________
          .'   \  \    \  \ `.
        /       \  \    \  \  '. 
       /\        |  |    |  |   \
      |  \       |  |    |  |    \
      |  /      _|__|____|__|__   \
      | /     /                \  | 
      |/      | <(=)>    <(=)> '  |
      |       |         _|     |  |
      | (|)   |  /\            |  |
      '       ' |  \____      /  ]
        '     '\ \_____/    .|  '
         '__,'  \_________.' |_/ 
                |____________\  ,.
              ,.              /\  \ 
            .`                ||   \
          .`                  ----\ \               
         /                    <== |, \         
        /                     <== | \_\
       '                      ---/     |      
       `._     /|                \____/         
       /  `-,./ |                 '
      /     /   |                 |        
     (______`'._|_________________|       By Geoff Sims © 1998 